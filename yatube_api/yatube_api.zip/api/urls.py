from django.urls import path, include
from rest_framework.authtoken import views
from api.views import PostModelViewSet, GroupModelViewSet, CommentModelViewSet
from rest_framework import routers


router = routers.DefaultRouter()
router.register(r'posts', PostModelViewSet)
router.register(r'groups', GroupModelViewSet)
router.register(r'posts/(?P<post_id>\d+)/comments',
                CommentModelViewSet, basename='comments')

app_name = 'posts'

urlpatterns = [
    path('api/v1/api-token-auth/', views.obtain_auth_token),
    path('api/v1/', include(router.urls)),

]
